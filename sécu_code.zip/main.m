% main script
nb_traces = 20000;
%% load traces
load_data();

%% extract traces corresponding to the last round
traces_last = extract_last_round(traces);

%% plot first trace
plot_trace();

%% plot avg
plot_average_trace(traces);
hold on;
xline(1123, "--b", "Round 1");
xline(3131, "--k", "Dernier round");
hold off;

%% attack
state_predict();

%% hamming weight attack
hamming_weight_attack();

%% key to get
disp("key to get is ")
key = '4C8CDF23B5C906F79057EC7184193A67';
disp(key)   
key_dec = zeros(16, 1);
for i = 1:16
    key_dec(i) = hex2dec(key((2*i)-1 : 2*i));
end

w = uint8(zeros(11, 4, 4));
w(1, :, :) = reshape(key_dec, 4, 4);

for i = 1:10
    w(i+1, :, :) = key_schu(squeeze(w(i, :, :)), i);
end

key_to_get = squeeze(w(11, :, :));
disp("key to get is ")
disp(key_to_get)

disp("best candidate is ")
disp(reshape(best_candidate, 4, 4))

disp("nbre de correspondances ")
disp(sum(sum(key_to_get == reshape(best_candidate, 4, 4))))